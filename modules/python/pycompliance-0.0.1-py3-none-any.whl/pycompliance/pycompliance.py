from enum import IntEnum
import uuid
import datetime
import json

class ComplianceMessage:

	def __init__(self, title, message, level):
		self.ComplianceCheckFunction = title
		self.ComplianceCheckMessageText = message
		self.ComplianceCheckTimestamp = datetime.datetime.utcnow().isoformat() + "Z"
		self.ComplianceCheckLevel = level

	def jsonable(self):
		return self.__dict__


class ComplianceResult:

	def __init__(self):
		self.ResultLevel = StatusLevel(StatusLevelEnum.UNKNOWN)
		self.StatusMessages = []
		self.ExecutionId = str(uuid.uuid4())

	def AddComplianceMessage(self, cMessage):
		self.StatusMessages.append(cMessage)

	def SetOverallStatusLevel(self):
		statusSet = set()
		for message in self.StatusMessages:
			if message.ComplianceCheckLevel.Status not in statusSet:
				statusSet.add(message.ComplianceCheckLevel.Status)


		if StatusLevelEnum.CRITICAL in statusSet:
			self.ResultLevel = StatusLevel(StatusLevelEnum.CRITICAL)
		elif StatusLevelEnum.WARNING in statusSet:
			self.ResultLevel = StatusLevel(StatusLevelEnum.WARNING)
		elif StatusLevelEnum.OK in statusSet:
			self.ResultLevel = StatusLevel(StatusLevelEnum.OK)
		else:
			self.ResultLevel = StatusLevel(StatusLevelEnum.UNKNOWN)

	def jsonable(self):
		return self.__dict__

	def PrintJsonToConsole(self):
		jsonstr = json.dumps(self, default=ComplexHandler)
		print(jsonstr)

def ComplexHandler(obj):
	if hasattr(obj, 'jsonable'):
		return obj.jsonable()
	else:
		raise TypeError 


class StatusLevel:
	def __init__(self, status):
		self.Status = status

	def jsonable(self):
		return self.__dict__


class StatusLevelEnum(IntEnum):
	OK = 0
	WARNING = 1
	CRITICAL = 2
	UNKNOWN = 3
